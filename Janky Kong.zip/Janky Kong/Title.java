import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Title here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import greenfoot.*;

public class Title extends Actor {
    GifImage gifImage = new GifImage("Title.gif");

    public void act() {
        setImage(gifImage.getCurrentImage());

        if (!BackGround1.gameStarted && (Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("w"))) {
            BackGround1.gameStarted = true;
            getWorld().removeObject(this);
        }
    }
}

