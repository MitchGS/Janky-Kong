import greenfoot.*;

public class Hammer extends Actor {
    private int rotationSpeed = 5;
    private int rotationDirection = 1;
    private boolean isActive = false;
    private int activeTime = 0;
    private int maxActiveTime = 200;
    private int cooldownTime = 1000;
    private int currentCooldown = 0;

    public void Hammer() { 
        GreenfootImage image = new GreenfootImage("hammer.png");
        setImage(image);
    }

    public void act() {
        handleCooldown();

        if (isActive) {
            handleActive();
        } else {
            handleInactive();
        }

        handleRotation();
    }

    public void handleCooldown() {
        if (currentCooldown > 0) {
            currentCooldown--;
        }
    }

    public void handleActive() {
        activeTime++;
        if (activeTime >= maxActiveTime) {
            isActive = false;
            activeTime = 0;
            currentCooldown = cooldownTime;
        }

        if (isTouching(Barrel.class)) {
            removeTouching(Barrel.class);
        }
    }

    public void handleInactive() {
        if (getY() >= getWorld().getHeight() || (isTouching(Mario.class) && Greenfoot.isKeyDown("space") && currentCooldown == 0)) {
            getWorld().removeObject(this);
            isActive = true;
        }
    }

    public void handleRotation() {
        if (isActive) {
            setRotation(getRotation() + (rotationSpeed * rotationDirection));

            if (getRotation() >= 30 || getRotation() <= -30) {
                rotationDirection *= -1;
            }
        }
    }
}
