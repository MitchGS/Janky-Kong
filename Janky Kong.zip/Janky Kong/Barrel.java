import greenfoot.*;

public class Barrel extends Actor {
    private GreenfootImage defaultImage;
    private GreenfootImage alternateImage;
    private boolean isBetweenFloors;

    public Barrel() {
        alternateImage = new GreenfootImage("Donkey_Kong_Classic_NES_Artwork.jpg");
        defaultImage = new GreenfootImage("Donkey_Kong_Classic_NES_Artwork21cardioawyeahproduction1738imlikeheywhatsuphello.png");
        setImage(defaultImage);
        isBetweenFloors = false;
    }

    public void act() {
        setLocation(getX() + BackGround1.backgroundXSpeed, getY() + BackGround1.backgroundYSpeed + 3);

        if (isAtEdge() || getY() >= 990) {
            getWorld().removeObject(this);
        } else {
            boolean touchingFloor2 = isTouching(Floor2.class);
            boolean touchingFloor = isTouching(Floor.class);

            if (touchingFloor2 || touchingFloor) {
                if (!isBetweenFloors) {
                    setImage(defaultImage);
                    isBetweenFloors = true;
                }
            } else {
                if (isBetweenFloors) {
                    setImage(alternateImage);
                    isBetweenFloors = false;
                }
            }

            if (touchingFloor2) {
                setLocation(getX() - 3, getY() - 3);
                turn(-8);
            } else if (touchingFloor) {
                setLocation(getX() + 3, getY() - 3);
                turn(8);
            }
        }
    }
}
