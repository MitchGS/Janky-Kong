import greenfoot.*;

/**
 * Write a description of class Floor2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Floor2 extends Floor
{
    /**
     * Act - do whatever the Floor2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        setLocation( getX(), getY() +BackGround1.backgroundY);  
    }    
}
