import greenfoot.*; 

public class Princess extends Actor
{
    public void act()
    {
    }
}
