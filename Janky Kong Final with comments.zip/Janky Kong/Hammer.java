import greenfoot.*;

public class Hammer extends Actor {
    // Variables to control the hammer's rotation and state
    private int rotationSpeed = 5; // Speed of rotation
    private int rotationDirection = 1; // Direction of rotation 1 for clockwise -1 for counter clockwise
    private boolean isActive = false; // Check if the hammer is active
    private boolean isActivated = false; // Check if the hammer is activated
    private int activeTime = 0; // Counter for the active time
    private int maxActiveTime = 200; // Maximum time the hammer can be active
    private boolean isRemoved = false; // Check if the hammer is removed

    // Constructor for Hammer
    public Hammer() { 
        GreenfootImage image = new GreenfootImage("hammer.png"); // Load the hammer image
        setImage(image); // Set the image for the hammer
    }

    // The act method is called repeatedly
    public void act() {
        // If the hammer is removed, exit the method
        if (isRemoved) {
            return; 
        }

        // Handle the hammers behavior based on its active state
        if (isActive) {
            handleActive(); // Handle the active state
        } else {
            handleInactive(); // Handle the inactive state
        }

        handleRotation(); // Handle the rotation of the hammer

        // If the hammer is marked as removed, delay and remove it from the world
        if (isRemoved) {
            Greenfoot.delay(1); // Delay to allow for any last action
            getWorld().removeObject(this); // Remove the hammer from the world
        }
    }

    // Method to handle the hammers behavior when active
    public void handleActive() {
        activeTime++; // Increment the active time
        // If the active time reaches the maximum deactivate and mark the hammer for removal
        if (activeTime >= maxActiveTime) {
            isActive = false;
            activeTime = 0;
            isRemoved = true;
        }

        // If the hammer is touching a Barrel remove the Barrel
        if (isTouching(Barrel.class)) {
            removeTouching(Barrel.class);
        }
    }

    // Method to handle the hammers behavior when inactive
    public void handleInactive() {
        // If the hammer is not activated and the space key is pressed activate it
        if (!isActivated && Greenfoot.isKeyDown("space")){
            isActivated = true;
        }

        // If the hammer is activated and touching Mario make it active
        if (isActivated && isTouching(Mario.class)) {
            isActive = true;
            isActivated = false;
        }
    }

    // Method to handle the rotation of the hammer
    public void handleRotation() {
        // If the hammer is active rotate it
        if (isActive) {
            setRotation(getRotation() + (rotationSpeed * rotationDirection)); // Rotation

            // If the rotation reaches a certain angle reverse the rotation direction
            if (getRotation() >= 30 || getRotation() <= -30) {
                rotationDirection *= -1;
            }
        }
    }
}
