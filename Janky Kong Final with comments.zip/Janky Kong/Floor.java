import greenfoot.*;

public class Floor extends Actor
{
    public void act() 
    {
        // Move the floor based on the background's speed
        setLocation(getX() + BackGround1.backgroundXSpeed, getY() + BackGround1.backgroundYSpeed);
        
        // Check if the floor's Y position is not less than 990
        if(!(getY() < 990)){
            // If the floor is at or below Y position 990 remove it from the world
            getWorld().removeObject(this);
        }        
    }    
}
