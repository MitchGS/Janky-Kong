import greenfoot.*;

public class Heart extends Actor
{
    public void act()
    {
        // An image. We probably could have just called this directly from the filesystem huh. whats done is done.
    }
}
