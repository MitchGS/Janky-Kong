import greenfoot.*;

public class Mario extends Actor {

    // Moves the background down by changing the vertical speed to negative
    public static void moveBackgroundDown() {
        BackGround1.backgroundYSpeed = -ySpeed; 
    }

    // Moves the background left by decreasing the horizontal position
    public static void moveBackgroundLeft() {
        BackGround1.backgroundXSpeed = -5; // Sets the speed to move left
        BackGround1.backgroundXPos += 5; // Adjusts the position to create a scrolling effect
    }

    // Moves the background right by increasing the horizontal position
    public static void moveBackgroundRight() {
        BackGround1.backgroundXSpeed = 5; // Sets the speed to move right
        BackGround1.backgroundXPos -= 5; // Adjusts the position to create a scrolling effect
    }

    // Initializes Mario
    public void setMario() {
        setImage(marioIdle); // Sets the initial image for Mario
        timer = 0; // Resets the animation timer
        spriteNum = 0; // Resets the sprite animation frame counter
    }

    // Changes marios sprite image based on a timer to animate movement
    public void changeSprite(){
        if(System.currentTimeMillis() - timer > 200){ // Checks if 200ms have passed
            spriteNum += 1; // Advances to the next sprite frame
            spriteNum = spriteNum % 3; // Loops back to the first sprite after the third
            timer = System.currentTimeMillis(); // Resets the timer
        }
    }

    // Checks and executes marios leftward movement
    public void checkMoveLeft(){
        if(Greenfoot.isKeyDown("left") || Greenfoot.isKeyDown("a")){ // Checks for left movement keys
            facingRight = false; // Sets the facing direction to left
            if(getX() > 50){ // Checks if mario is not too close to the left edge
                move(-5); // Moves mario left
            }
            // Changes marios sprite based on the current frame number
            switch(spriteNum){
                case 0:
                    setImage("marioLeft1.png");
                    break;
                case 1:
                    setImage("marioLeft2.png");
                    break;
                case 2:
                    setImage("marioLeft3.png");
                    break;
                default:
                    setImage("marioLeft1.png");
                    break;
            }
            // The commented code below would adjust marios position if overlapping with the Floor class
            // while(isTouching(Floor.class)){
            //    move(1);
            //} 
        }
    }

    // Checks and executes marios rightward movement
    public void checkMoveRight(){
        if(Greenfoot.isKeyDown("right") || Greenfoot.isKeyDown("d")){ // Checks for right movement keys
            facingRight = true; // Sets the facing direction to right
            // Changes marios sprite based on the current frame number
            switch(spriteNum){
                case 0:
                    setImage("marioRight1.png");
                    break;
                case 1:
                    setImage("marioRight2.png");
                    break;
                case 2:
                    setImage("marioRight3.png");
                    break;
                default:
                    setImage("marioRight1.png");
                    break;
            }
            if(getX() < 1250){ // Checks if mario is not too close to the right edge
                move(5); // Moves mario right
            }
            // The commented code below would adjust Mario's position if overlapping with the Floor class
            // while(isTouching(Floor.class)){
            //     move(-1);
            // }
        }
    }

    // variable for vertical speed
    static int ySpeed;
    // Timer for sprite animation
    long timer = 0;
    // Player lives
    int Lives = 3;
    // Player score
    int score = 0;
    // Current sprite frame number
    int spriteNum = 0;

    // Mario's sprite images for different states and actions
    private GreenfootImage marioLeft1 = new GreenfootImage("marioLeft1.png");
    private GreenfootImage marioLeft2 = new GreenfootImage("marioLeft2.png");
    private GreenfootImage marioLeft3 = new GreenfootImage("marioLeft3.png");
    private GreenfootImage marioRight1 = new GreenfootImage("marioRight1.png");
    private GreenfootImage marioRight2 = new GreenfootImage("marioRight2.png");
    private GreenfootImage marioRight3 = new GreenfootImage("marioRight3.png");
    private GreenfootImage marioIdle = new GreenfootImage("marioIdle.png");
    private GreenfootImage marioIdleLeft = new GreenfootImage("marioIdleLeft.png");
    private GreenfootImage marioDeath = new GreenfootImage("marioDeath.png");
    private GreenfootImage marioJumpRight = new GreenfootImage("marioJumpRight.png");
    private GreenfootImage marioJumpLeft = new GreenfootImage("marioJumpLeft.png");

    // Boolean to track which direction Mario is facing
    private boolean facingRight = true;

    // Main method that is called repeatedly to update game state
    public void act() {
        // Set Mario's image based on the direction he is facing
        if(facingRight){
            setImage(marioIdle);
        }else{
            setImage(marioIdleLeft);
        }

        // Call method to change marios sprite for animation
        changeSprite();

        // Reset background speeds to 0 for this act cycle
        BackGround1.backgroundYSpeed = 0;
        BackGround1.backgroundXSpeed = 0;

        // Increment ySpeed for gravity effect
        ySpeed += 1;

        // Update Mario's vertical position or move the background down
        if (getY() > 500 || ySpeed == Math.abs(ySpeed)) {
            setLocation(getX(), getY() + ySpeed);
        } else {
            moveBackgroundDown();
        }

        // Display lives and score on the screen
        getWorld().showText("Lives: " + Lives, 1200, 350);
        getWorld().showText("Score: " + score, 1200, 380);

        // Increment score by 1 for every act() call (adjust as needed)
        score += 1;

        // Check for left and right movement
        checkMoveLeft();
        checkMoveRight();

        // Adjust marios position if he is touching the floor while the background is moving
        if(BackGround1.backgroundYSpeed != 0 && isTouching(Floor.class)){
            while(isTouching(Floor.class)){
                setLocation(getX(), getY() + 1);
            }
        }

        // If mario is fallingcheck for floor collision and allow jumping
        if(ySpeed > 0) {
            while(isTouching(Floor.class)) {
                ySpeed = 0;
                setLocation(getX(), getY() - 1);
                if(Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("w")) {
                    ySpeed = -27; // Set jump speed
                }
            }
        }

        // If mario is moving upwards adjust his position if he touches the floor
        if(ySpeed <= 0) {
            while(isTouching(Floor.class)) {
                ySpeed = 0;
                setLocation(getX(), getY() + 1);
            }
        }

        // if the down key is pressed increase ySpeed to simulate fast falling
        if(Greenfoot.isKeyDown("down") || Greenfoot.isKeyDown("s")) {
            ySpeed = 50;
        }

        // if mario is touching a ladder allow him to climb up or down
        if (isTouching(Ladder.class)) {
            if (Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("w")) {
                setLocation(getX(), getY() - 2); // Climb up
            } else if (Greenfoot.isKeyDown("down") || Greenfoot.isKeyDown("s")) {
                setLocation(getX(), getY() + 2); // Climb down
            }
        }

        // Change mario image to jumping sprite if he is in the air
        if(ySpeed != 0) {
            if(facingRight) {
                setImage(marioJumpRight);
            } else {
                setImage(marioJumpLeft);
            }
        }

        // Check for collision with Barrel class or if Mario falls off the world
        if(isTouching(Barrel.class) || getY() > 990) {
            removeTouching(Barrel.class);
            // Check if Mario would lose a life or if its game over
            if(Lives < 2 || getY() > 990) {
                Lives = 0;
                setImage(marioDeath);
                getWorld().showText("GAME OVER", 750, 600);
                Greenfoot.stop(); // Stop the game
            }
            Lives--; // -- lives
        }
    }
}