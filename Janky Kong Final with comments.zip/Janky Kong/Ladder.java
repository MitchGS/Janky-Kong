import greenfoot.*;  

public class Ladder extends Actor
{
   
    public void act()
    {
        // Update the Ladder's location based on the backgrounds movement
        setLocation(getX() + BackGround1.backgroundXSpeed, getY() + BackGround1.backgroundYSpeed);
        
        // Check if the Ladder's Y position is less than 990
        if(!(getY() < 990)){
            // If the Ladder is at or below Y position 990 remove it from the world
            getWorld().removeObject(this);
        }
    }
}
