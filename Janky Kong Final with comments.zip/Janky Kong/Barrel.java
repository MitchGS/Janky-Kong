import greenfoot.*;

public class Barrel extends Actor {
    // Variables to hold the images for the barrel
    private GreenfootImage defaultImage;
    private GreenfootImage alternateImage;
    private boolean isBetweenFloors; // Check if the barrel is between floors

    // Constructor for the Barrel
    public Barrel() {
        // Load images for the barrel
        alternateImage = new GreenfootImage("Donkey_Kong_Classic_NES_Artwork.jpg");
        defaultImage = new GreenfootImage("Donkey_Kong_Classic_NES_Artwork21cardioawyeahproduction1738imlikeheywhatsuphello.png");
        setImage(defaultImage); // Set the initial image for the barrel
        isBetweenFloors = false; // Initialize isBetweenFloors
    }

    // The act method is called repeatedly
    public void act() {
        // Move the barrel based on the backgrounds speed and downward speed
        setLocation(getX() + BackGround1.backgroundXSpeed, getY() + BackGround1.backgroundYSpeed + 3);

        // Remove the barrel from the world if it reaches the edge or a position
        if (isAtEdge() || getY() >= 990) {
            getWorld().removeObject(this);
        } else {
            // Check if the barrel is touching Floor2 or Floor
            boolean touchingFloor2 = isTouching(Floor2.class);
            boolean touchingFloor = isTouching(Floor.class);

            // Change the barrel's image based on whether it is between floors or not
            if (touchingFloor2 || touchingFloor) {
                if (!isBetweenFloors) {
                    setImage(defaultImage);
                    isBetweenFloors = true;
                }
            } else {
                if (isBetweenFloors) {
                    setImage(alternateImage);
                    isBetweenFloors = false;
                }
            }

            // Adjust the barrel's position and rotation based on the type of floor it is touching
            if (touchingFloor2) {
                setLocation(getX() - 3, getY() - 3); // Move up and left
                turn(-8); // Turn counter clockwise
            } else if (touchingFloor) {
                setLocation(getX() + 3, getY() - 3); // Move up and right
                turn(8); // Turn clockwise
            }
        }
    }
}
