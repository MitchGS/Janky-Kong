import greenfoot.*;

public class BackGround1 extends World {
    // Variables to control background movement and game state
    public static int backgroundYSpeed = 0;
    public static int backgroundXSpeed = 0;
    public static int backgroundXPos = 0;
    public static boolean gameStarted = false; // Check if the game has started
    public static boolean objectsConstructed = false; // Check if the objects are constructed

    // Variables for mario and Hammer objects
    private Mario mario = new Mario();
    private Hammer hammer;
    private int prevMarioX; // To keep track of marios previous X position

    // The act method is called repeatedly 
    public void act() {
        // Check if the game has started
        if (gameStarted) {
            // Check if the objects have been constructed
            if(objectsConstructed){
                // Get Mario's current position
                int marioX = mario.getX();
                int marioY = mario.getY();

                // Set hammers location based on marios movement direction
                if (marioX < prevMarioX) {
                    hammer.setLocation(marioX - 80, marioY);
                } else {
                    hammer.setLocation(marioX + 80, marioY);
                }

                // Update marios prvious X position
                prevMarioX = marioX; 
            } else {
                // Construct game objects if not already done
                mario = new Mario();
                int[] floor1Y = {219, 781}; // Y cordinates for the first type of floor
                int[] floor2Y = {500, 989}; // Y cordinates for the secnd type of floor

                // Add floors to the world
                addFloor1s(floor1Y, 125, 875);
                addFloor2s(floor2Y, 625, 1375);

                // Add Mario, Hammer, and other objects to the world
                addObject(mario, 125, 940);
                hammer = new Hammer();
                addObject(hammer, mario.getX() + 50, mario.getY());
                prevMarioX = mario.getX();
                addObject(new DK(), 200, 150);
                addObject(new Ladder(), 634, 886);
                addObject(new Floor2(), 125, 989);
                addObject(new Floor2(), 250, 989);
                addObject(new Floor2(), 375, 989);
                mario.setMario(); // Initalize Mario
                objectsConstructed = true; // Set to true after construction
            }
        }
    }

    // Construcor for BackGround1
    public BackGround1() {
        super(1500, 1000, 1); 
        gameStarted = false; // Initalize gameStarted
        objectsConstructed = false; // Initialize objectsConstructed

        // Add the title object to the world
        addObject(new Title(), 800, 450);
    }
    
    // Method to add the first type of floor objects to the world
    public void addFloor1s(int[] yCoords, int startX, int endX) {
        // Loop through the given Y-coordinates
        for (int y : yCoords) {
            // Create floor objects at intervals along the X-axis
            for (int x = startX; x <= endX; x += 250) {
                addObject(new Floor(), x, y);
            }
        }
    }

    // Method to add the second type of floor objects to the world
    public void addFloor2s(int[] yCoords, int startX, int endX) {
        // Loop through the given Y-coordinates
        for (int y : yCoords) {
            // Create floor2 objects at intervals along the X-axis
            for (int x = startX; x <= endX; x += 250) {
                addObject(new Floor2(), x, y);
            }
        }
    }
}
