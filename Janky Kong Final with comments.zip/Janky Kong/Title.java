import greenfoot.*;

public class Title extends Actor {
    // Create a new GifImage object to handle the title GIF
    GifImage gifImage = new GifImage("Title.gif");

    public void act() {
        // Set the current image of the title animation
        setImage(gifImage.getCurrentImage());

        // Check if the game hasn't started and if the player presses the 'up' or 'w' key
        if (!BackGround1.gameStarted && (Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("w"))) {
            // Set the game as started
            BackGround1.gameStarted = true;
            // Remove the title object from the world
            getWorld().removeObject(this);
        }
    }
}

