import greenfoot.*;

public class Mario extends Actor {
    public static void moveBackgroundDown() {
        BackGround1.backgroundYSpeed = -ySpeed;
    }

    public static void moveBackgroundLeft() {
        BackGround1.backgroundXSpeed = -5;
        BackGround1.backgroundXPos +=5;
    }

    public static void moveBackgroundRight() {
        BackGround1.backgroundXSpeed = 5;
        BackGround1.backgroundXPos -=5;
    }

    public void setMario() {
        setImage(marioIdle);
        timer = 0;
        spriteNum = 0;
    }

    public void changeSprite(){
        if(System.currentTimeMillis()-timer>200){
            spriteNum+=1;
            spriteNum = spriteNum % 3;
            timer = System.currentTimeMillis();
        }
    }
    public void checkMoveLeft(){
        if(Greenfoot.isKeyDown("left")||Greenfoot.isKeyDown("a"))
        {
            facingRight = false;
            if(getX()>50){
                move(-5);
            }
            switch(spriteNum){
                        case 0:
                            setImage("marioLeft1.png");
                            break;
                        case 1:
                            setImage("marioLeft2.png");
                            break;
                        case 2:
                            setImage("marioLeft3.png");
                            break;
                        default:
                            setImage("marioLeft1.png");
                            break;
                    }
            //while(isTouching(Floor.class))
            //{
            //    move(1);
            //} 
        }
    }
    public void checkMoveRight(){
        if(Greenfoot.isKeyDown("right")||Greenfoot.isKeyDown("d"))
            {
                facingRight = true;
                switch(spriteNum){
                        case 0:
                            setImage("marioRight1.png");
                            break;
                        case 1:
                            setImage("marioRight2.png");
                            break;
                        case 2:
                            setImage("marioRight3.png");
                            break;
                        default:
                            setImage("marioRight1.png");
                            break;
                    }
                if(getX()<1250){
                    move(5);
                    

                   // while(isTouching(Floor.class))
                   // {
                   //     move(-1);
                   // }
                }
            }
    }

    static int ySpeed;
    long timer = 0;
    int Lives = 3;
    int score = 0;
    int spriteNum = 0;
    private GreenfootImage marioLeft1 = new GreenfootImage("marioLeft1.png");
    private GreenfootImage marioLeft2 = new GreenfootImage("marioLeft2.png");
    private GreenfootImage marioLeft3 = new GreenfootImage("marioLeft3.png");
    private GreenfootImage marioRight1 = new GreenfootImage("marioRight1.png");
    private GreenfootImage marioRight2 = new GreenfootImage("marioRight2.png");
    private GreenfootImage marioRight3 = new GreenfootImage("marioRight3.png");
    private GreenfootImage marioIdle = new GreenfootImage("marioIdle.png");
    private GreenfootImage marioIdleLeft = new GreenfootImage("marioIdleLeft.png");
    private GreenfootImage marioDeath = new GreenfootImage("marioDeath.png");
    private GreenfootImage marioJumpRight = new GreenfootImage("marioJumpRight.png");
    private GreenfootImage marioJumpLeft = new GreenfootImage("marioJumpLeft.png");

    private boolean facingRight = true;
    public void act() {
        if(facingRight){
        setImage(marioIdle);
    }else{
        setImage(marioIdleLeft);
    }
        changeSprite();
        BackGround1.backgroundYSpeed = 0;
        BackGround1.backgroundXSpeed = 0;
        ySpeed += 1;
        // Updates y position
        if (getY() > 500 || ySpeed == Math.abs(ySpeed)) {
            setLocation(getX(), getY() + ySpeed);
        } else {
            moveBackgroundDown();
        }

        // Display lives and score
        getWorld().showText("Lives: " + Lives, 1200, 350);
        getWorld().showText("Score: " + score, 1200, 380);
        // Update score based on time alive
        score += 1; // Increase score by 1 for every act() call (adjust as needed)
        checkMoveLeft();
        checkMoveRight();
        
        
        if(BackGround1.backgroundYSpeed!=0&&isTouching(Floor.class)){
            while(isTouching(Floor.class)){
                setLocation(getX(), getY() + 1);
            }
        }
        if(ySpeed > 0)
        {
            while(isTouching(Floor.class))
            {
                ySpeed = 0;
                setLocation(getX(), getY() - 1);
                if(Greenfoot.isKeyDown("up")||Greenfoot.isKeyDown("w"))
                {
                    ySpeed = - 27;

                }
            }
        }

        if(ySpeed <= 0)
        {
            while(isTouching(Floor.class))
            {
                ySpeed = 0;
                setLocation(getX(), getY() + 1);
            }
        }    
        if(Greenfoot.isKeyDown("down")||Greenfoot.isKeyDown("s"))
        {
            ySpeed = 50;
        } 
        if (isTouching(Ladder.class)) {
            if (Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("w")) {
                setLocation(getX(), getY() - 2); // Climb up
            } else if (Greenfoot.isKeyDown("down") || Greenfoot.isKeyDown("s")) {
                setLocation(getX(), getY() + 2); // Climb down
            }
        }
        if(ySpeed!=0){
            if(facingRight){
                setImage(marioJumpRight);
            }else{
                setImage(marioJumpLeft);
            }
        }
        if(isTouching(Barrel.class) || getY() > 990)
        {
            removeTouching(Barrel.class);
            if(Lives < 2 || getY() > 990) // checks if the player would have died on hit.
            {
                Lives = 0;
                setImage(marioDeath);
                getWorld().showText("GAME OVER", 750, 600);
                Greenfoot.stop();
            }
            Lives--; // updates players life
        }
    } 
}